var menudata={children:[
{text:"Página principal",url:"index.html"},
{text:"Classes",url:"annotated.html",children:[
{text:"Lista de componentes",url:"annotated.html"},
{text:"Índice dos componentes",url:"classes.html"},
{text:"Componentes membro",url:"functions.html",children:[
{text:"Tudo",url:"functions.html"},
{text:"Variáveis",url:"functions_vars.html"}]}]},
{text:"Ficheiros",url:"files.html",children:[
{text:"Lista de ficheiros",url:"files.html"},
{text:"Membros dos Ficheiros",url:"globals.html",children:[
{text:"Tudo",url:"globals.html",children:[
{text:"a",url:"globals.html#index_a"},
{text:"b",url:"globals.html#index_b"},
{text:"c",url:"globals.html#index_c"},
{text:"e",url:"globals.html#index_e"},
{text:"i",url:"globals.html#index_i"},
{text:"l",url:"globals.html#index_l"},
{text:"m",url:"globals.html#index_m"},
{text:"p",url:"globals.html#index_p"},
{text:"s",url:"globals.html#index_s"},
{text:"t",url:"globals.html#index_t"}]},
{text:"Funções",url:"globals_func.html",children:[
{text:"a",url:"globals_func.html#index_a"},
{text:"b",url:"globals_func.html#index_b"},
{text:"e",url:"globals_func.html#index_e"},
{text:"i",url:"globals_func.html#index_i"},
{text:"l",url:"globals_func.html#index_l"},
{text:"m",url:"globals_func.html#index_m"},
{text:"p",url:"globals_func.html#index_p"},
{text:"s",url:"globals_func.html#index_s"},
{text:"t",url:"globals_func.html#index_t"}]},
{text:"Definições de tipos",url:"globals_type.html"},
{text:"Macros",url:"globals_defs.html"}]}]}]}
