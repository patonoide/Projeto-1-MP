var indexSectionsWithContent =
{
  0: "abcdefilmpstv",
  1: "t",
  2: "acfmt",
  3: "abeilmpst",
  4: "deipv",
  5: "a",
  6: "c"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "defines"
};

var indexSectionLabels =
{
  0: "Tudo",
  1: "Classes",
  2: "Ficheiros",
  3: "Funções",
  4: "Variáveis",
  5: "Definições de tipos",
  6: "Macros"
};

