var searchData=
[
  ['test_5fcase',['TEST_CASE',['../testa_arvore_8cpp.html#a2a49339ba2ec897c4883cf4fb299580a',1,'TEST_CASE(&quot;Testa a arvore&quot;, &quot;&quot;):&#160;testaArvore.cpp'],['../teste_jogo_8cpp.html#ae1a9e334b18e963cf56a1c4e6017781f',1,'TEST_CASE(&quot;Testa o jogo&quot;, &quot;&quot;):&#160;testeJogo.cpp']]],
  ['testaarvore_2ecpp',['testaArvore.cpp',['../testa_arvore_8cpp.html',1,'']]],
  ['testejogo_2ecpp',['testeJogo.cpp',['../teste_jogo_8cpp.html',1,'']]],
  ['tree',['tree',['../structtree.html',1,'']]],
  ['treevazia',['treeVazia',['../arvore_8cpp.html#a1e488a964749b5d848abf0d1bfbd0427',1,'treeVazia():&#160;arvore.cpp'],['../arvore_8h.html#a1e488a964749b5d848abf0d1bfbd0427',1,'treeVazia():&#160;arvore.cpp'],['../cabecalho_8h.html#a1e488a964749b5d848abf0d1bfbd0427',1,'treeVazia():&#160;arvore.cpp']]]
];
