var searchData=
[
  ['esq',['esq',['../structtree.html#aed1a08ff52888fc196c29399e9f0f7e9',1,'tree']]],
  ['excluir',['excluir',['../arvore_8cpp.html#ae38aad8f5458b7f9747addbbcc270cfa',1,'excluir(Arvore *a, char *valor):&#160;arvore.cpp'],['../arvore_8h.html#ae38aad8f5458b7f9747addbbcc270cfa',1,'excluir(Arvore *a, char *valor):&#160;arvore.cpp'],['../cabecalho_8h.html#ae38aad8f5458b7f9747addbbcc270cfa',1,'excluir(Arvore *a, char *valor):&#160;arvore.cpp']]]
];
