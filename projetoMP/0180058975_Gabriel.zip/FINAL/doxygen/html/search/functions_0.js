var searchData=
[
  ['altura',['altura',['../arvore_8cpp.html#ac6bb8a4fc7472c16f5f758a7f7425f68',1,'altura(Arvore *a):&#160;arvore.cpp'],['../arvore_8h.html#ac6bb8a4fc7472c16f5f758a7f7425f68',1,'altura(Arvore *a):&#160;arvore.cpp'],['../cabecalho_8h.html#ac6bb8a4fc7472c16f5f758a7f7425f68',1,'altura(Arvore *a):&#160;arvore.cpp']]]
];
