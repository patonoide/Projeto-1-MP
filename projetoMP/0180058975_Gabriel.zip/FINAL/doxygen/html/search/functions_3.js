var searchData=
[
  ['iniciararvore',['iniciarArvore',['../cabecalho_8h.html#ab265aff45a8223e8f902ab3d30d21bd2',1,'iniciarArvore(Arvore *tree):&#160;cabecalho.h'],['../funcoes_8cpp.html#aeb36377a497066501bbcc6a97a736c09',1,'iniciarArvore():&#160;funcoes.cpp']]],
  ['iniciarjogo',['iniciarJogo',['../cabecalho_8h.html#a458c8696d1dffab882b4656e85e4c27e',1,'iniciarJogo(Arvore *a):&#160;funcoes.cpp'],['../funcoes_8cpp.html#aa298d891844b52c8d87c7e69b2c2943b',1,'iniciarJogo(Arvore *tree):&#160;funcoes.cpp']]],
  ['inordem',['inOrdem',['../arvore_8cpp.html#aa32120be50528a44bc8e5216c1092c95',1,'inOrdem(Arvore *a):&#160;arvore.cpp'],['../arvore_8h.html#aa32120be50528a44bc8e5216c1092c95',1,'inOrdem(Arvore *a):&#160;arvore.cpp'],['../cabecalho_8h.html#aa32120be50528a44bc8e5216c1092c95',1,'inOrdem(Arvore *a):&#160;arvore.cpp']]],
  ['insere',['insere',['../arvore_8cpp.html#a2021f7adc04c5fe4cf9e90b211f8d28d',1,'insere(Arvore *a, char *palavra):&#160;arvore.cpp'],['../arvore_8h.html#a63dfdaef389beac40e6099c5c6479dd9',1,'insere(Arvore *a, char *valor):&#160;arvore.cpp'],['../cabecalho_8h.html#a2b8bbde153b71525a0368ad1f49df4f8',1,'insere(Arvore *a, int valor, char *palavra):&#160;cabecalho.h'],['../cabecalho_8h.html#a63dfdaef389beac40e6099c5c6479dd9',1,'insere(Arvore *a, char *valor):&#160;arvore.cpp']]]
];
