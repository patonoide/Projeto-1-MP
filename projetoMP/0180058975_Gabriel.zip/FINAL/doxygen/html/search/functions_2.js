var searchData=
[
  ['excluir',['excluir',['../arvore_8cpp.html#ae38aad8f5458b7f9747addbbcc270cfa',1,'excluir(Arvore *a, char *valor):&#160;arvore.cpp'],['../arvore_8h.html#ae38aad8f5458b7f9747addbbcc270cfa',1,'excluir(Arvore *a, char *valor):&#160;arvore.cpp'],['../cabecalho_8h.html#ae38aad8f5458b7f9747addbbcc270cfa',1,'excluir(Arvore *a, char *valor):&#160;arvore.cpp']]]
];
