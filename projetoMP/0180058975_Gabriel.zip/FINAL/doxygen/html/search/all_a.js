var searchData=
[
  ['salvararvore',['salvarArvore',['../cabecalho_8h.html#ad7fd104dae4c5632636ee639f8833351',1,'salvarArvore(Arvore *a):&#160;funcoes.cpp'],['../funcoes_8cpp.html#aa3c3430baa283b012b264551a41e9872',1,'salvarArvore(Arvore *tree):&#160;funcoes.cpp']]]
];
