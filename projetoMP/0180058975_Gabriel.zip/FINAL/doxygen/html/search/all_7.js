var searchData=
[
  ['libera',['libera',['../arvore_8cpp.html#a0d448d5dd01cd251c9ebb9b1eef12564',1,'libera(Arvore *a):&#160;arvore.cpp'],['../arvore_8h.html#a0d448d5dd01cd251c9ebb9b1eef12564',1,'libera(Arvore *a):&#160;arvore.cpp'],['../cabecalho_8h.html#a0d448d5dd01cd251c9ebb9b1eef12564',1,'libera(Arvore *a):&#160;arvore.cpp']]]
];
